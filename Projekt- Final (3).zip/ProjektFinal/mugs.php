<?php 
session_start();
require 'database/dbconn.php';

// Hämtar priset för en produkt från databasen baserat på produktens ID och använder real_escape_string för att skydda mot SQL-injektion.
$product_id = 2;

$product_id_safe = $dbconn->real_escape_string($product_id);
$sql = "SELECT price FROM products WHERE product_id = '$product_id_safe'";

$result = $dbconn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    $price = $row['price'];
} else {
    $price = "N/A";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5 GoblinZ Mug</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <style>
        .mug-grid-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 20px;
            margin: 20px;
        }

        .mug-item {
            width: 30%;
            background-color: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-decoration: none;
            color: #333333;
        }

        .mug-item img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .mug-item h2 {
            font-size: 18px;
            margin: 10px 0;
        }

        .mug-item .price {
            font-size: 16px;
            margin: 10px 0;
        }

        .mug-item button {
            background: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            border-radius: 5px;
        }

        .mug-item button:hover {
            background: #555;
        }

        .mug-item a {
            color: #333333;
            text-decoration: none;
        }

        .mug-item a:visited {
            color: #333333;
        }

        .mug-item a:hover {
            color: black;
        }

        @media (max-width: 1024px) {
            .mug-item {
                width: 48%;
            }
        }

        @media (max-width: 768px) {
            .mug-item {
                width: 100%;
            }
        }
    </style>
</head>
<body>
	<!--Header -->
    <div class="header happy-monkey-regular">Celebrating our new store! Free shipping on everything!</div>
    <img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

	<!-- navbar -->
    <nav class="navbar happy-monkey-regular">
        <ul class="nav-list">
            <li><a href="index.php">Home</a></li>
            <li><a href="store.html">Store</a></li>
            <li class="dropdown">
                <a href="#teams" class="dropbtn">Products</a>
                <div class="dropdown-content">
                    <a href="Tshirts.php">T-shirts</a>
                    <a href="keycaps.php">Keycaps</a>
                    <a href="headwear.php">Headwear</a>
                    <a href="mugs.php">Mugs</a>
                </div>
            </li>
            <li><a href="bestsellers.php">Best Sellers</a></li>
        </ul>
    </nav>

	<!-- kundvagnen -->
    <div class="cart-container">
        <a href="cartcheckout.php" class="cart-link">
            <div class="cart-icon">🛒</div>
        </a>
    </div>

    <div class="mug-grid-container happy-monkey-regular">
        <div class="mug-item">
            <a href="5goblinzmug.php">
                <img src="assets/images/plainmug1.png" alt="mug">
                <h2>5 GoblinZ Mug</h2>
            </a>
            <p class="price">$<?php echo number_format($price, 2); ?></p>
			<!-- lägger i kundvagnen -->
            <form action="add_to_cart.php" method="POST" style="display: inline;">
                <input type="hidden" name="product_id" value="2">
                <button type="submit" class="happy-monkey-regular">Add to Cart</button>
            </form>
        </div>

        <div class="mug-item">
            <img src="assets/images/questionmark.png" alt="mug2">
            <h2>Coming soon...</h2>
            <p class="price">$420.00</p>
        </div>

        <div class="mug-item">
            <img src="assets/images/questionmark.png" alt="mug3">
            <h2>Coming soon...</h2>
            <p class="price">$420.00</p>
        </div>
    </div>

	<!-- footer -->
    <footer class="footer" style="margin-top: 197px;">
        <div class="footer-content">
            <p>&copy; 2025 5GZ Store. All rights reserved.</p>
            <p>Follow us on:
                <a href="#" target="_blank">Instagram</a> | 
                <a href="#" target="_blank">Twitter/X</a> | 
                <a href="#" target="_blank">TikTok</a>
            </p>
        </div>
    </footer>
</body>
</html>
