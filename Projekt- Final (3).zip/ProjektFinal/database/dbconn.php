<?php

$dbhost = "localhost";
$dbuser = "eetumiktge22a_phpuser";
$dbpwd = "SRkAPWAm*0xb";
$dbname = "eetumiktge22a_projekt";

#Skapar en uppkoppling mot databasen
$dbconn = new mysqli($dbhost, $dbuser, $dbpwd, $dbname);

if($dbconn->connect_error){
	die("Fel på uppkopplingen:".$dbconn->connect_error);
}

?>