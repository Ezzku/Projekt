<?php
session_start();
require 'database/dbconn.php';

// Rensar alla varor från kundens kundvagn i databasen baserat på session_id och vidarebefordrar till cart.php.
if (isset($_POST['remove_all']) && $_POST['remove_all'] == 1) {
    $session_id = session_id();

    if ($dbconn->connect_error) {
        die("Connection failed: " . $dbconn->connect_error);
    }

    $sql = "DELETE FROM cart WHERE session_id = ?";
    $stmt = $dbconn->prepare($sql);
    $stmt->bind_param("s", $session_id);
    $stmt->execute();
    $stmt->close();
}

header("Location: cartcheckout.php");
exit;
?>
