<?php 
session_start();
//Kollar om du är inloggad
if (!isset($_SESSION["logged_in"])) {
    header("Location: login.php");
    exit;
}

?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Admin Panel</title>
<link rel="stylesheet" href="assets/styles1.css">
</head>

<body>
<!--HEADER-->
<div class="header happy-monkey-regular" style="color: white;">Admin Panel - Manage Your Store</div>
<img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

<!--Navbar-->
<nav class="navbar happy-monkey-regular">
    <ul class="nav-list">
        <li><a href="index.php">Home</a></li>
        <li><a href="admin.php">Admin Panel</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<!--CONTENT-->
<div class="admin-container happy-monkey-regular" style="text-align: center; margin-top: 50px;">
    <h1 style="color: white;">Welcome to the Admin Panel</h1>
    <button class="admin-btn" onclick="location.href='orders.php'">Orders</button>
    <button class="admin-btn" onclick="location.href='stock.php'">Stock</button>
</div>

<!--STYLES-->
<style>
    .admin-container {
        padding: 20px;
    }
    .admin-btn {
        background-color: #007bff;
        color: white;
        padding: 15px 30px;
        margin: 10px;
        border: none;
        border-radius: 10px;
        cursor: pointer;
        font-size: 18px;
    }
    .admin-btn:hover {
        background-color: #0056b3;
    }
</style>

</body>
</html>
