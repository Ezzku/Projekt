<?php

session_start();
//Kollar om du är inloggad
if (!isset($_SESSION["logged_in"])) {
    header("Location: login.php");
    exit;
}


require 'database/dbconn.php';

// Hanterar lagersaldouppdatering via POST och hämtar alla produkter från databasen för visning eller vidare bearbetning.
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_stock'])) {
    $product_id = intval($_POST['product_id']);
    $new_stock = intval($_POST['new_stock']);

    $stmt = $dbconn->prepare("UPDATE products SET stock = ? WHERE product_id = ?");
    $stmt->bind_param("ii", $new_stock, $product_id);
    if ($stmt->execute()) {
        echo "<script>alert('Stock updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating stock.');</script>";
    }
}

$result = $dbconn->query("SELECT * FROM products");
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin - Stock Management</title>
    <link rel="stylesheet" href="assets/styles1.css">
</head>
<body>

<!-- HEADER -->
<div class="header happy-monkey-regular">Admin Panel - Manage Stock</div>
<img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

<!-- Navbar -->
<nav class="navbar happy-monkey-regular">
    <ul class="nav-list">
        <li><a href="index.php">Home</a></li>
        <li><a href="admin.php">Admin Panel</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<!-- Stock Management Table -->
<div class="card happy-monkey-regular">
    <h2>Stock Management</h2>
    <table border="1" style="width: 100%; text-align: center;">
        <tr>
            <th>Product ID</th>
            <th>Name</th>
            <th>Stock</th>
            <th>Update Stock</th>
        </tr>
        <?php while ($row = $result->fetch_assoc()) : ?>
        <tr>
            <td><?php echo $row['product_id']; ?></td>
            <td><?php echo htmlspecialchars($row['name']); ?></td>
            <td><?php echo $row['stock']; ?></td>
            <td>
                <form method="post">
                    <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                    <input type="number" name="new_stock" value="<?php echo $row['stock']; ?>" min="0">
                    <button type="submit" name="update_stock">Update</button>
                </form>
            </td>
        </tr>
        <?php endwhile; ?>
    </table>
</div>

</body>
</html>
