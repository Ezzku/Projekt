<?php  
// startar sessionen 
session_start();  

// avslutar sessionen om anv�ndaren �r inloggad  
if (isset($_SESSION["logged_in"])) {  
    unset($_SESSION["logged_in"]);  
}  

header("Location: index.php");  
?> 