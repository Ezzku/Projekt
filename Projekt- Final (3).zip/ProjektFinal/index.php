<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Home of 5GoblinZ</title>
	<link rel="stylesheet" href="assets/styles1.css">
</head>

<body>
<!--HEADER-->

<div class="header happy-monkey-regular">Celebrating our new store! Free shipping on everything!</div>
<img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">
	

	
<!--Navbar-->
	
<nav class="navbar happy-monkey-regular">
	<ul class="nav-list">
		<li><a href="index.php">Home</a></li>
		<li class="dropdown">
			<a href="#teams" class="dropbtn">Teams</a>
			<div class="dropdown-content">
				<a href="csteam.html">Counter-Strike 2</a>
				<a href="commingsoon.html">Comming soon...</a>
			</div>
		</li>
		<li><a href="aboutus.html">About Us</a></li>
		<li><a href="store.html">Store</a></li>
	</ul>
</nav>	

<!--Content-->
	
<div class="container">


<!-- Karusell -->	
<div class="carousel">
	<div class="carousel-images">
		<img src="assets/images/5gzwide.png" alt="Image 1">
		<img src="assets/images/plainshirt1.png" alt="Image 2">
		<img src="assets/images/plainshirt1.png" alt="Image 3">
	</div>
	<button class="prev">&#10094;</button>
	<button class="next">&#10095;</button>
</div>

</div>


<script>
const prevButton = document.querySelector('.prev');
const nextButton = document.querySelector('.next');
const carouselImages = document.querySelector('.carousel-images');
let index = 0;

nextButton.addEventListener('click', () => {
index = (index + 1) % 3;
updateCarousel();
});

prevButton.addEventListener('click', () => {
index = (index - 1 + 3) % 3;
updateCarousel();
});

function updateCarousel() {
carouselImages.style.transform = `translateX(-${index * 100}%)`;
}
</script>

<h1 class="happy-monkey-regular" style="text-align: center; color: white;">Welcome! We are GoblinZ</h1>

<h1 class="happy-monkey-regular" style="text-align: center; color: white;">Go check out our newly released store!🔥</h1>

<a href="store.html">
  <img src="assets/images/storepicture.png" alt="store" 
       style="display: block; margin: 5px auto; border-radius: 10px; 
              box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); cursor: pointer;">
</a>

<!--Footer-->
	
<footer class="footer">
  <div class="footer-content">
    <p>&copy; 2025 5GZ Store. All rights reserved.</p>
    <p>Follow us on:
      <a href="#" target="_blank">Instagram</a> | 
      <a href="#" target="_blank">Twitter</a> | 
      <a href="#" target="_blank">Facebook</a>
    </p>
  </div>
</footer>

</body>
</html>
