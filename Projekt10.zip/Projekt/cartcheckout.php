<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="assets/styles1.css">
</head>
<style>


.checkout-container {
    background-color: #222;
    max-width: 1000px;
    margin: 30px auto;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(255, 255, 255, 0.2);
    text-align: left;
}

.checkout-container h2 {
    text-align: center;
    color: #ff4500;
}

.cart-items {
    background-color: #333;
    padding: 15px;
    border-radius: 5px;
    margin-bottom: 20px;
	color: white;
}

.cart-items h3 {
    margin: 0;
    color: #ff4500;
}

.cart-items ul {
    list-style: none;
    padding: 0;
}

.cart-items ul li {
    padding: 5px 0;
    border-bottom: 1px solid #555;
}

form {
    display: flex;
    flex-direction: column;
}

label {
	color: white;
    font-size: 16px;
    margin-bottom: 5px;
	text-align: center;
}

textarea {
    width: 100%;
    border-radius: 5px;
    border: none;
    resize: none;
    background-color: #444;
    color: white;
    margin-bottom: 15px;
    font-size: 16px;
    text-align: center;
    line-height: 15px;
	padding-top: 5px;
}

button {
    background-color: #ff4500;
    border: none;
    padding: 12px;
    color: white;
    font-size: 18px;
    cursor: pointer;
    border-radius: 5px;
    transition: background 0.3s ease;
}

button:hover {
    background-color: #e03e00;
}
	
</style>
<body>

<script>
function getCart() {
    let cart = localStorage.getItem("cart");
    return cart ? JSON.parse(cart) : {};
}

function saveCart(cart) {
    localStorage.setItem("cart", JSON.stringify(cart));
}

function calculateTotal(cart) {
    let prices = {
        1: 89.99, 
        2: 19.99,  
        3: 24.99, 
        4: 15.99   
    };

    let total = 0;
    for (let productId in cart) {
        total += (prices[productId] || 0) * cart[productId];
    }
    return total.toFixed(2);
}

function removeFromCart(productId) {
    let cart = getCart();

    if (cart[productId]) {
        delete cart[productId];
        saveCart(cart);
        populateCart();
    }
}

function populateCart() {
    let cart = getCart();
    let cartList = document.getElementById("cart-list");
    let totalAmount = document.getElementById("total-amount");
    let hiddenTotal = document.getElementById("hidden-total");
    let placeOrderButton = document.querySelector("button[type='submit']");

    cartList.innerHTML = "";

    if (Object.keys(cart).length === 0) {
        cartList.innerHTML = "<li>Your cart is empty</li>";
        totalAmount.textContent = "0.00";
        hiddenTotal.value = "0.00";
        placeOrderButton.disabled = true;
        return;
    }

    placeOrderButton.disabled = false;

    let prices = {
        1: 89.99,
        2: 19.99,
        3: 24.99,
        4: 15.99
    };

    let productNames = {
        1: "5 GoblinZ T-shirt",
        2: "5 GoblinZ Mug",
        3: "5 GoblinZ Beanie",
        4: "5 GoblinZ Keycap"
    };

    for (let productId in cart) {
        let quantity = cart[productId];
        let productName = productNames[productId] || "Unknown Product";
        let price = (quantity * (prices[productId] || 0)).toFixed(2);

        let listItem = document.createElement("li");
        listItem.innerHTML = `${productName} x${quantity} - $${price} `;

        let removeButton = document.createElement("button");
        removeButton.textContent = "Remove";
        removeButton.style.marginLeft = "10px";
        removeButton.style.backgroundColor = "red";
        removeButton.style.color = "white";
        removeButton.style.border = "none";
        removeButton.style.padding = "5px 10px";
        removeButton.style.cursor = "pointer";
        removeButton.onclick = function () {
            removeFromCart(productId);
        };

        listItem.appendChild(removeButton);
        cartList.appendChild(listItem);
    }

    totalAmount.textContent = calculateTotal(cart);
    hiddenTotal.value = calculateTotal(cart);
}

window.onload = function () {
    populateCart();
};
</script>



<div class="header happy-monkey-regular">
    Celebrating our new store! Free shipping on everything!
</div>

<img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

<!-- Navbar -->
<nav class="navbar happy-monkey-regular">
    <ul class="nav-list">
        <li><a href="index1.php">Home</a></li>
        <li><a href="store.php">Store</a></li>
        <li><a href="bestsellers.php">Best Sellers</a></li>
    </ul>
</nav>

<!-- Checkout Form -->
<div class="checkout-container happy-monkey-regular">
    <h2>Checkout</h2>
    
    <div class="cart-items">
        <h3>Your Cart</h3>
        <ul id="cart-list">
        </ul>
        <p><strong>Total:</strong> $<span id="total-amount">0.00</span></p>
    </div>

	<form action="process_checkout.php" method="POST">
		<label for="name">Full Name:</label>
		<textarea id="name" name="name" required></textarea>

		<label for="shipping_address">Shipping Address:</label>
		<textarea id="shipping_address" name="shipping_address" required></textarea>

		<input type="hidden" name="total_amount" id="hidden-total">

		<button type="submit" class="happy-monkey-regular">Place Order</button>
	</form>

</div>

<footer class="footer" style="margin-top: 197px;">
  <div class="footer-content">
    <p>&copy; 2025 5GZ Store. All rights reserved.</p>
    <p>Follow us on:
      <a href="#" target="_blank">Instagram</a> | 
      <a href="#" target="_blank">Twitter/X</a> | 
      <a href="#" target="_blank">TikTok</a>
    </p>
  </div>
</footer>

</body>
</html>
