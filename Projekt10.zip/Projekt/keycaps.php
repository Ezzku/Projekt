<?php 
session_start();
require 'database/dbconn.php';

$product_id = 3;

$product_id_safe = $dbconn->real_escape_string($product_id);
$sql = "SELECT price FROM products WHERE product_id = '$product_id_safe'";

$result = $dbconn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    $price = $row['price'];
} else {
    $price = "N/A";
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keycaps</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <script>
        function addToCart() {
            alert("Product added to cart!");
        }
    </script>
    <style>
		.tshirt-grid-container {
			display: flex;
			flex-wrap: wrap;
			justify-content: center;
			gap: 20px;
			margin: 20px;
		}

		.tshirt-item {
			width: 30%;
			background-color: #f9f9f9;
			border-radius: 10px;
			padding: 20px;
			text-align: center;
			box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
			text-decoration: none;
			color: #333333;
	
		}

		.tshirt-item img {
			max-width: 100%;
			height: auto;
			border-radius: 10px;
		}

		.tshirt-item h2 {
			font-size: 18px;
			margin: 10px 0;
		}

		.tshirt-item .price {
			font-size: 16px;
			margin: 10px 0;
		}

		.tshirt-item button {
			background: #333;
			color: white;
			padding: 10px 20px;
			border: none;
			cursor: pointer;
			font-size: 14px;
			border-radius: 5px;
		}

		.tshirt-item button:hover {
			background: #555;
		}

		@media (max-width: 1024px) {
			.tshirt-item {
				width: 48%;
			}
		}


		@media (max-width: 768px) {
			.tshirt-item {
				width: 100%;
			}
    	}    
</style>
</head>
<body>
    <div class="header happy-monkey-regular">Celebrating our new store! Free shipping on everything!</div>
    <img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">
    
<nav class="navbar happy-monkey-regular">
	<ul class="nav-list">
		<li><a href="index1.html">Home</a></li>
		<li><a href="store.html">Store</a></li>
		<li class="dropdown">
			<a href="#teams" class="dropbtn">Products</a>
			<div class="dropdown-content">
				<a href="T-shirts.php">T-shirts</a>
				<a href="keycaps.php">Keycaps</a>
				<a href="headwear.php">Headwear</a>
				<a href="mugs.php">Mugs</a>
			</div>
		</li>
		<li><a href="bestsellers.php">Best Sellers</a></li>

	</ul>
</nav>	

<div class="cart-container">
<a href="cartcheckout.html" class="cart-link">
  <div class="cart-icon">
    🛒 <span class="cart-counter">0</span>
  </div>
  <div class="cart-dropdown">
    <p>No items in cart</p>
  </div>
</a>
</div>

    <div class="tshirt-grid-container happy-monkey-regular">
        <a href="5goblinzkeycap.html" class="tshirt-item">
            <img src="assets/images/plainkeycap1.png" alt="mug">
            <h2>5 GoblinZ T-shirt</h2>
            <p class="price">$<?php echo number_format($price, 2);?></p>
            <button onclick="addToCart()">Add to Cart</button>
        </a>

        <div class="tshirt-item">
            <img src="assets/images/questionmark.png" alt="keycap2">
            <h2>Coming soon...</h2>
            <p class="price">$420.00</p>
        </div>

        <div class="tshirt-item">
            <img src="assets/images/questionmark.png" alt="keycap3">
            <h2>Coming soon...</h2>
            <p class="price">$420.00</p>
        </div>
    </div>

<footer class="footer" style="margin-top: 197px;">
  <div class="footer-content">
    <p>&copy; 2025 5GZ Store. All rights reserved.</p>
    <p>Follow us on:
      <a href="#" target="_blank">Instagram</a> | 
      <a href="#" target="_blank">Twitter/X</a> | 
      <a href="#" target="_blank">TikTok</a>
    </p>
  </div>
</footer>

</body>
</html>
