<?php
session_start();
require 'database/dbconn.php';

$session_id = session_id();

if ($dbconn->connect_error) {
    die("Connection failed: " . $dbconn->connect_error);
}

$sql = "SELECT c.quantity, p.product_id, p.name, p.price 
        FROM cart c
        JOIN products p ON c.product_id = p.product_id
        WHERE c.session_id = ?";

$stmt = $dbconn->prepare($sql);
$stmt->bind_param("s", $session_id);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$total = 0;

while ($row = $result->fetch_assoc()) {
    $row['subtotal'] = $row['price'] * $row['quantity'];
    $total += $row['subtotal'];
    $cart_items[] = $row;
}

$stmt->close();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $shipping_address = $_POST['shipping_address'];

    $dbconn->begin_transaction();

    try {
        $order_sql = "INSERT INTO orders (session_id, name, shipping_address, order_date, status, payment_method) 
                      VALUES (?, ?, ?, NOW(), 'Pending', 'Unpaid')";
        $stmt = $dbconn->prepare($order_sql);
        $stmt->bind_param("sss", $session_id, $name, $shipping_address);
        $stmt->execute();
        $order_id = $stmt->insert_id;
        $stmt->close();

        foreach ($cart_items as $item) {
            $order_item_sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                               VALUES (?, ?, ?, ?)";
            $stmt = $dbconn->prepare($order_item_sql);
            $stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
            $stmt->execute();
            $stmt->close();

            $update_stock_sql = "UPDATE products 
                                 SET stock = stock - ? 
                                 WHERE product_id = ?";
            $stmt = $dbconn->prepare($update_stock_sql);
            $stmt->bind_param("ii", $item['quantity'], $item['product_id']);
            $stmt->execute();
            $stmt->close();
        }

        $dbconn->commit();

        $clear_cart_sql = "DELETE FROM cart WHERE session_id = ?";
        $stmt = $dbconn->prepare($clear_cart_sql);
        $stmt->bind_param("s", $session_id);
        $stmt->execute();
        $stmt->close();

        header("Location: thank_you.php?order_id=" . $order_id);
        exit;
    } catch (Exception $e) {
        $dbconn->rollback();
        echo "Error: " . $e->getMessage();
    }
}
?>
