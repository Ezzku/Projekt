<?php 
session_start();
require 'database/dbconn.php';

$product_id = 4;

$product_id_safe = $dbconn->real_escape_string($product_id);
$sql = "SELECT price FROM products WHERE product_id = '$product_id_safe'";

$result = $dbconn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    $price = $row['price'];
} else {
    $price = "N/A";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5 GoblinZ Beanie</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <script>
        function addToCart() {
            alert("Product added to cart!");
        }
    </script>
</head>
<body>
    <div class="header happy-monkey-regular">Celebrating our new store! Free shipping on everything!</div>
    <img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">
    
<nav class="navbar happy-monkey-regular">
	<ul class="nav-list">
		<li><a href="index1.html">Home</a></li>
		<li><a href="store.html">Store</a></li>
		<li class="dropdown">
			<a href="#teams" class="dropbtn">Products</a>
			<div class="dropdown-content">
				<a href="T-shirts.html">T-shirts</a>
				<a href="keycaps.html">Keycaps</a>
				<a href="headwear.html">Headwear</a>
				<a href="mugs.html">Mugs</a>
			</div>
		</li>
		<li><a href="bestsellers.html">Best Sellers</a></li>
	</ul>
</nav>	

<div class="cart-container">
<a href="cartcheckout.html" class="cart-link">
  <div class="cart-icon">
    🛒 <span class="cart-counter">0</span>
  </div>
  <div class="cart-dropdown">
    <p>No items in cart</p>
  </div>
</a>
</div>
    
    <div class="product-container happy-monkey-regular">
        <div class="product">
            <img src="assets/images/plainbeanie1.png" alt="5 GoblinZ Beanie" width="300">
            <h2>5 GoblinZ Beanie</h2>
            <p class="price">Price: <strong>$<?php echo number_format($price, 2); ?></strong></p>
            <p class="description">Stay warm and stylish with the official 5 GoblinZ Beanie. Made from premium knitted fabric, perfect for any season.</p>
            
            <button onclick="addToCart()" class="happy-monkey-regular" style="background: #333333; color: white; padding: 10px 20px; margin-top: 10px;">Add to Cart</button>
        </div>
        
        <div class="product-details">
            <h3>Product Details</h3>
            <ul>
                <li>Material: High-quality acrylic knit</li>
                <li>Color: Black with embroidered 5 GoblinZ logo</li>
                <li>Size: One size fits all</li>
                <li>Unisex design</li>
            </ul>
        </div>
		
	</div>

<footer class="footer" style="margin-top: 197px;">
  <div class="footer-content">
    <p>&copy; 2025 5GZ Store. All rights reserved.</p>
    <p>Follow us on:
      <a href="#" target="_blank">Instagram</a> | 
      <a href="#" target="_blank">Twitter/X</a> | 
      <a href="#" target="_blank">TikTok</a>
    </p>
  </div>
</footer>

</body>
</html>
