<?php
session_start();
require 'database/dbconn.php';

// Lägger till eller uppdaterar hur många produkter av den sorten som finns i kundvagnen

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    $session_id = session_id();
    $product_id = (int)$_POST['product_id'];

    $check_sql = "SELECT quantity FROM cart WHERE session_id = ? AND product_id = ?";
    $check_stmt = $dbconn->prepare($check_sql);
    $check_stmt->bind_param("si", $session_id, $product_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();

    if ($check_result->num_rows > 0) {
        $update_sql = "UPDATE cart SET quantity = quantity + 1 WHERE session_id = ? AND product_id = ?";
        $update_stmt = $dbconn->prepare($update_sql);
        $update_stmt->bind_param("si", $session_id, $product_id);
        $update_stmt->execute();
        $update_stmt->close();
    } else {
        $insert_sql = "INSERT INTO cart (session_id, product_id, quantity) VALUES (?, ?, 1)";
        $insert_stmt = $dbconn->prepare($insert_sql);
        $insert_stmt->bind_param("si", $session_id, $product_id);
        $insert_stmt->execute();
        $insert_stmt->close();
    }

    $check_stmt->close();
}

header("Location: " . $_SERVER['HTTP_REFERER']);
exit;
