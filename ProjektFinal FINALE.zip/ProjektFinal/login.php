<?php
session_start();
ob_start();

// Kontrollerar att användaren är inloggad och skickar hen till admin.php
if (isset($_SESSION["logged_in"]) && $_SESSION["logged_in"] === true) {
    header("Location: admin.php");
    exit;
}

// lagrar användarnamn och lösenord i variabler
$user = "";
$pwd = "";

// Funktion för att rensa och säkra användardata
function cleanData($data){
    $data = strip_tags($data);
    $data = htmlspecialchars($data);
    return $data;
}

if (isset($_POST["username"]) && isset($_POST["password"])) {
    require "database/dbconn.php"; // ansluter till databasen

    $pwd = cleanData($_POST['password']);
    $user = cleanData($_POST['username']);
    
    // Hämtar användardata från databasen
    $sql = "SELECT * FROM users WHERE uname = ?";
    if ($stmt = $dbconn->prepare($sql)) {
        // Bind parameters (s = string)
        $stmt->bind_param("s", $user);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $row = $result->fetch_assoc();
            $hash = $row['pwd']; // Hämta hashad lösenord från databasen
            
            // Verifiera om lösenordet stämmer
            if (password_verify($pwd, $hash)) {
                $_SESSION["logged_in"] = true;
                header("Location: admin.php"); // Redirect to admin.php after successful login
                exit;
            } else {
                $errormsg = "Du har angivit fel användarnamn eller lösenord!";
            }
        } else {
            $errormsg = "Användaren finns inte!";
        }
        $stmt->close(); // Stänger prepared statement
    }

    $dbconn->close(); // Stänger anslutning
}

if (isset($errormsg)) {
    echo '<p class="error">' . $errormsg . '</p>';
}
?>

<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Logga in</title>
<link rel="stylesheet" href="assets/styles1.css">
</head>

<body onLoad="document.loginform.username.focus();"> <!--Sätter focus på användarnamns fältet då sidan laddas-->
    <!--HEADER-->
    <div class="header happy-monkey-regular">Logga in till Admin Panel</div>
    <img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">
    
    <!--Navbar-->
    <nav class="navbar happy-monkey-regular">
        <ul class="nav-list">
            <li><a href="index1.html">Home</a></li>
            <li><a href="aboutus.html">About Us</a></li>
            <li><a href="store.html">Store</a></li>
        </ul>
    </nav>

    <p style="color: white; text-align: center; font-size: 64px;" class="happy-monkey-regular">Admin Login</p>
    
    <!--Login Form-->
    <form id="loginform" name="loginform" method="post" action=""> <!--Skapar ett formulär för att logga in-->
        <fieldset>
            <legend>Logga in</legend><br>
            <label for="username">Användarnamn:</label> <br>
            <input type="text" name="username" id="username" size="30"> <br>
            <label for="password">Lösenord:</label> <br>
            <input type="password" name="password" id="password" size="30"> <br><br>
            <label for="submit"></label>
            <input type="submit" name="submit" id="submit" value="Logga in"> <!--Knappen skickar datan-->
        </fieldset>
    </form>

</body>
</html>
