<?php
$order_id = isset($_GET['order_id']) ? $_GET['order_id'] : 'unknown';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thank You</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <style>
        body {
            font-family: 'Happy Monkey', sans-serif;
            background-color: #222;
            color: white;
            text-align: center;
            padding: 50px;
        }
        h1 {
            color: #ff4500;
        }
        button {
            background-color: #ff4500;
            border: none;
            padding: 12px;
            color: white;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s ease;
        }
        button:hover {
            background-color: #e03e00;
        }
    </style>
</head>
<body>
    <h1>Thank You for Your Order!</h1>
    <p>Your order ID is: <?php echo htmlspecialchars($order_id); ?></p>
    <a href="index.php"><button>Back to Home</button></a>
</body>
</html>
