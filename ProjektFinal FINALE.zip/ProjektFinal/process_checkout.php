<?php
session_start();
require 'database/dbconn.php';

$session_id = session_id();

if ($dbconn->connect_error) {
    die("Connection failed: " . $dbconn->connect_error);
}

// SQL-frågan hämtar information om varor som finns i kundvagnen för en specifik session.
$sql = "SELECT c.quantity, p.product_id, p.name, p.price 
        FROM cart c
        JOIN products p ON c.product_id = p.product_id
        WHERE c.session_id = ?";

// Koden förbereder en SQL-fråga (så den blir säker mot t.ex. hackning), sätter in användarens session-ID som ett värde i frågan, kör frågan mot databasen, och hämtar sedan resultatet (de varor som finns i kundvagnen för just den sessionen).
$stmt = $dbconn->prepare($sql);
$stmt->bind_param("s", $session_id);
$stmt->execute();
$result = $stmt->get_result();

//förbereder plats att lagra både varor och det totala priset innan man börjar räkna ihop dem.
$cart_items = [];
$total = 0;

while ($row = $result->fetch_assoc()) {
    $row['subtotal'] = $row['price'] * $row['quantity'];
    $total += $row['subtotal'];
    $cart_items[] = $row;
}

$stmt->close();

// Hämtar namn och leveransadress från POST-data
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $shipping_address = $_POST['shipping_address'];

	// startar en transaktion i databasen, vilket gör att alla följande SQL-ändringar kan behandlas som en enhet och rullas tillbaka om något går fel.
    $dbconn->begin_transaction();

    try {
		// gör en ny order i tabellen
        $order_sql = "INSERT INTO orders (session_id, name, shipping_address, order_date, status) 
                      VALUES (?, ?, ?, NOW(), 'Pending')";
        $stmt = $dbconn->prepare($order_sql);
        $stmt->bind_param("sss", $session_id, $name, $shipping_address);
        $stmt->execute();
        $order_id = $stmt->insert_id;
        $stmt->close();

		//Loopa igenom varje vara i kundvagnen och lägg till den i 'order_items' samt uppdatera stock
        foreach ($cart_items as $item) {
            $order_item_sql = "INSERT INTO order_items (order_id, product_id, quantity, price) 
                               VALUES (?, ?, ?, ?)";
            $stmt = $dbconn->prepare($order_item_sql);
            $stmt->bind_param("iiid", $order_id, $item['product_id'], $item['quantity'], $item['price']);
            $stmt->execute();
            $stmt->close();

            $update_stock_sql = "UPDATE products 
                                 SET stock = stock - ? 
                                 WHERE product_id = ?";
            $stmt = $dbconn->prepare($update_stock_sql);
            $stmt->bind_param("ii", $item['quantity'], $item['product_id']);
            $stmt->execute();
            $stmt->close();
        }

		// commitar ändringarna
        $dbconn->commit();

		//Tömmer kundvagnen tar bort varorna från 'cart' för den sessionen
        $clear_cart_sql = "DELETE FROM cart WHERE session_id = ?";
        $stmt = $dbconn->prepare($clear_cart_sql);
        $stmt->bind_param("s", $session_id);
        $stmt->execute();
        $stmt->close();

		//för till tacksidan med order idn
        header("Location: thank_you.php?order_id=" . $order_id);
        exit;
    } catch (Exception $e) {
        $dbconn->rollback();
        echo "Error: " . $e->getMessage();
    }
}
?>
