<?php 
session_start();
require 'database/dbconn.php';

// Hämtar priset för en produkt från databasen baserat på produktens ID och använder real_escape_string för att skydda mot SQL-injektion.
$product_id = 1;

$product_id_safe = $dbconn->real_escape_string($product_id);
$sql = "SELECT price FROM products WHERE product_id = '$product_id_safe'";

$result = $dbconn->query($sql);

if ($result && $row = $result->fetch_assoc()) {
    $price = $row['price'];
} else {
    $price = "N/A";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>5 GoblinZ T-shirt</title>
    <link rel="stylesheet" href="assets/styles1.css">
</head>
<body>
	<!--Header-->
    <div class="header happy-monkey-regular">Celebrating our new store! Free shipping on everything!</div>
    <img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

<!--Navbar-->
<nav class="navbar happy-monkey-regular">
	<ul class="nav-list">
		<li><a href="index.php">Home</a></li>
		<li><a href="store.html">Store</a></li>
		<li class="dropdown">
			<a href="#teams" class="dropbtn">Products</a>
			<div class="dropdown-content">
				<a href="Tshirts.php">T-shirts</a>
				<a href="keycaps.php">Keycaps</a>
				<a href="headwear.php">Headwear</a>
				<a href="mugs.php">Mugs</a>
			</div>
		</li>
		<li><a href="bestsellers.html">Best Sellers</a></li>

	</ul>
</nav>	

<!-- kundvagnen -->
<div class="cart-container">
<a href="cartcheckout.php" class="cart-link">
  <div class="cart-icon">🛒</div>
</a>
</div>
    
    <div class="product-container happy-monkey-regular">
        <div class="product">
            <img src="assets/images/plainshirt1.png" alt="5goblinztshirt" width="300">
            <h2>5 GoblinZ T-shirt</h2>
            <p class="price">Price: <strong>$<?php echo number_format($price, 2); ?></strong></p>
            <p class="description">Show off your team spirit with the official 5 GoblinZ T-shirt. Made from high-quality cotton for maximum comfort and durability.</p>
            
			<!-- lägger i kundvagnen -->
            <form action="add_to_cart.php" method="POST" style="display: inline;">
			<input type="hidden" name="product_id" value="<?php echo $product_id; ?>">
			<button type="submit" class="happy-monkey-regular" style="background: #333333; color: white; padding: 10px 20px; margin-top: 10px;">Add to Cart</button>
			</form>

        </div>
        
        <div class="product-details">
            <h3>Product Details</h3>
            <ul>
                <li>Material: 100% Cotton</li>
                <li>Color: Black</li>
                <li>Unisex fit</li>
                <li>Machine washable</li>
            </ul>
        </div>
    </div>

<!--Footer-->
<footer class="footer" style="margin-top: 197px;">
  <div class="footer-content">
    <p>&copy; 2025 5GZ Store. All rights reserved.</p>
    <p>Follow us on:
      <a href="#" target="_blank">Instagram</a> | 
      <a href="#" target="_blank">Twitter/X</a> | 
      <a href="#" target="_blank">TikTok</a>
    </p>
  </div>
</footer>
</body>
</html>
