<?php
session_start();
if (!isset($_SESSION["logged_in"])) {
    header("Location: login.php");
    exit;
}

require 'database/dbconn.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = $_POST['new_status'];

    $stmt = $dbconn->prepare("UPDATE orders SET status = ? WHERE order_id = ?");
    $stmt->bind_param("si", $new_status, $order_id);
    if ($stmt->execute()) {
        echo "<script>alert('Order status updated successfully!');</script>";
    } else {
        echo "<script>alert('Error updating order status.');</script>";
    }
}

$sql = "SELECT orders.order_id, orders.session_id, orders.name, orders.shipping_address, orders.order_date, orders.status, 
        GROUP_CONCAT(CONCAT(products.name, ' (', order_items.quantity, ')') SEPARATOR ', ') AS products, 
        SUM(order_items.quantity) AS total_items, 
        SUM(order_items.price * order_items.quantity) AS total_price 
        FROM orders 
        JOIN order_items ON orders.order_id = order_items.order_id 
        JOIN products ON order_items.product_id = products.product_id 
        GROUP BY orders.order_id 
        ORDER BY orders.order_date DESC";

$result = $dbconn->query($sql);
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Admin - Order Management</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <style>
        table {
            width: 100%;
            table-layout: fixed;
            border-collapse: collapse;
            font-size: 14px;
        }

        table th, table td {
            padding: 6px 8px;
            border: 1px solid #ccc;
            word-wrap: break-word;
            overflow-wrap: break-word;
            vertical-align: middle;
        }

        th.status-col {
            width: 90px;
        }

        th.update-col {
            width: 160px;
        }

        form select, form button {
            width: 100%;
            font-size: 12px;
            padding: 4px;
            box-sizing: border-box;
        }

        .card {
            max-width: 100%;
            margin: 5px auto;
            padding: 10px;
        }
    </style>
</head>
<body>

<!-- HEADER -->
<div class="header happy-monkey-regular">Admin Panel - Manage Orders</div>
<img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

<!-- Navbar -->
<nav class="navbar happy-monkey-regular">
    <ul class="nav-list">
        <li><a href="index1.html">Home</a></li>
        <li><a href="admin.php">Admin Panel</a></li>
        <li><a href="logout.php">Logout</a></li>
    </ul>
</nav>

<div class="card happy-monkey-regular">
    <h2 style="text-align: center;">Order Management</h2>
    <div style="overflow-x: auto;">
        <table>
            <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Shipping Address</th>
                <th>Products</th>
                <th>Total Items</th>
                <th>Total Price</th>
                <th>Order Date</th>
                <th class="status-col">Status</th>
                <th class="update-col">Update Status</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()) : ?>
            <tr>
                <td><?php echo $row['order_id']; ?></td>
                <td><?php echo htmlspecialchars($row['name']); ?></td>
                <td><?php echo htmlspecialchars($row['shipping_address']); ?></td>
                <td><?php echo htmlspecialchars($row['products']); ?></td>
                <td><?php echo $row['total_items']; ?></td>
                <td>$<?php echo number_format($row['total_price'], 2); ?></td>
                <td><?php echo $row['order_date']; ?></td>
                <td><?php echo $row['status']; ?></td>
                <td>
                    <form method="post">
                        <input type="hidden" name="order_id" value="<?php echo $row['order_id']; ?>">
                        <select name="new_status">
                            <option value="Pending" <?php if ($row['status'] == 'Pending') echo 'selected'; ?>>Pending</option>
                            <option value="Processing" <?php if ($row['status'] == 'Processing') echo 'selected'; ?>>Processing</option>
                            <option value="Completed" <?php if ($row['status'] == 'Completed') echo 'selected'; ?>>Completed</option>
                            <option value="Cancelled" <?php if ($row['status'] == 'Cancelled') echo 'selected'; ?>>Cancelled</option>
                        </select>
                        <button type="submit" name="update_status">Update</button>
                    </form>
                </td>
            </tr>
            <?php endwhile; ?>
        </table>
    </div>
</div>

</body>
</html>
