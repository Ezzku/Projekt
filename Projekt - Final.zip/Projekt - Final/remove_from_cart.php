<?php
session_start();
require 'database/dbconn.php';

if (isset($_POST['remove_all']) && $_POST['remove_all'] == 1) {
    $session_id = session_id();

    if ($dbconn->connect_error) {
        die("Connection failed: " . $dbconn->connect_error);
    }

    $sql = "DELETE FROM cart WHERE session_id = ?";
    $stmt = $dbconn->prepare($sql);
    $stmt->bind_param("s", $session_id);
    $stmt->execute();
    $stmt->close();
}

header("Location: testitest.php");
exit;
?>
