<?php
session_start();
require 'database/dbconn.php';

$session_id = session_id();

if ($dbconn->connect_error) {
    die("Connection failed: " . $dbconn->connect_error);
}

$sql = "SELECT c.quantity, c.product_id, p.name, p.price 
        FROM cart c
        JOIN products p ON c.product_id = p.product_id
        WHERE c.session_id = ?";

$stmt = $dbconn->prepare($sql);
$stmt->bind_param("s", $session_id);
$stmt->execute();
$result = $stmt->get_result();

$cart_items = [];
$total = 0;

while ($row = $result->fetch_assoc()) {
    $row['subtotal'] = $row['price'] * $row['quantity'];
    $total += $row['subtotal'];
    $cart_items[] = $row;
}

$stmt->close();
$dbconn->close();
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <style>
        .checkout-container {
            background-color: #222;
            max-width: 1000px;
            margin: 30px auto;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(255, 255, 255, 0.2);
            text-align: left;
        }
        .checkout-container h2 {
            text-align: center;
            color: #ff4500;
        }
        .cart-items {
            background-color: #333;
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
            color: white;
        }
        .cart-items h3 {
            margin: 0;
            color: #ff4500;
        }
        .cart-items div {
            padding: 5px 0;
            border-bottom: 1px solid #555;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .remove-button {
            background-color: #c0392b;
            border: none;
            color: white;
            padding: 6px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        button {
            background-color: #ff4500;
            border: none;
            padding: 12px;
            color: white;
            font-size: 18px;
            cursor: pointer;
            border-radius: 5px;
            transition: background 0.3s ease;
        }
        button:hover {
            background-color: #e03e00;
        }
        label {
            color: white;
            font-size: 16px;
            margin-bottom: 5px;
        }
        textarea {
            width: 100%;
            border-radius: 5px;
            border: none;
            resize: none;
            background-color: #444;
            color: white;
            margin-bottom: 15px;
            font-size: 16px;
            text-align: center;
            line-height: 15px;
            padding-top: 5px;
        }
    </style>
</head>
<body>

<div class="header happy-monkey-regular">
    Celebrating our new store! Free shipping on everything!
</div>

<img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">

<nav class="navbar happy-monkey-regular">
    <ul class="nav-list">
        <li><a href="index.php">Home</a></li>
        <li><a href="store.html">Store</a></li>
        <li><a href="bestsellers.php">Best Sellers</a></li>
    </ul>
</nav>

<div class="checkout-container happy-monkey-regular">
    <h2>Checkout</h2>

    <form action="process_checkout.php" method="POST">
        <div class="cart-items">
            <h3>Your Cart</h3>

            <?php if (count($cart_items) > 0): ?>
                <?php foreach ($cart_items as $item): ?>
                    <div>
                        <span>
                            <?php echo htmlspecialchars($item['name']); ?> 
                            (x<?php echo (int)$item['quantity']; ?>) – 
                            $<?php echo number_format($item['subtotal'], 2); ?>
                        </span>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Your cart is empty.</p>
            <?php endif; ?>

            <p><strong>Total:</strong> $<span id="total-amount"><?php echo number_format($total, 2); ?></span></p>
            <input type="hidden" name="total_amount" id="hidden-total" value="<?php echo number_format($total, 2); ?>">
        </div>

        <label for="name">Full Name:</label>
        <textarea id="name" name="name" required></textarea>

        <label for="shipping_address">Shipping Address:</label>
        <textarea id="shipping_address" name="shipping_address" required></textarea>

        <button type="submit" class="happy-monkey-regular">Place Order</button>
    </form>

    <form method="POST" action="remove_from_cart.php" style="margin-top: 20px;">
        <input type="hidden" name="remove_all" value="1">
        <button type="submit" class="remove-button" style="width: 100%;">Remove All Items from Cart</button>
    </form>
</div>

<footer class="footer" style="margin-top: 197px;">
  <div class="footer-content">
    <p>&copy; 2025 5GZ Store. All rights reserved.</p>
    <p>Follow us on:
      <a href="#" target="_blank">Instagram</a> | 
      <a href="#" target="_blank">Twitter/X</a> | 
      <a href="#" target="_blank">TikTok</a>
    </p>
  </div>
</footer>

</body>
</html>
