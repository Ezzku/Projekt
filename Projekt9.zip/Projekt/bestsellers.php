<?php 
session_start();
require 'database/dbconn.php';

$product_ids = [1, 2, 3, 4];
$prices = [];

foreach ($product_ids as $product_id) {
    $product_id_safe = $dbconn->real_escape_string($product_id);

    $sql = "SELECT price FROM products WHERE product_id = '$product_id_safe'";
    $result = $dbconn->query($sql);

    if ($result && $row = $result->fetch_assoc()) {
        $prices[$product_id] = $row['price'];
    } else {
        $prices[$product_id] = "N/A";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Sellers</title>
    <link rel="stylesheet" href="assets/styles1.css">
    <script>
        function getCart() {
            let cart = localStorage.getItem('cart');
            return cart ? JSON.parse(cart) : {};
        }

        function saveCart(cart) {
            localStorage.setItem('cart', JSON.stringify(cart));
        }

        function addToCart(productId) {
            let cart = getCart();

            if (cart[productId]) {
                cart[productId] += 1;
            } else {
                cart[productId] = 1;
            }

            saveCart(cart);

            updateCartCounter();
            updateCartDropdown();

            alert("Product added to cart!");
        }

        function removeFromCart(productId) {
            let cart = getCart();

            if (cart[productId]) {
                delete cart[productId];
            }

            saveCart(cart);

            updateCartCounter();
            updateCartDropdown();
        }

        function updateCartCounter() {
            let cart = getCart();
            let totalItems = 0;
            for (let productId in cart) {
                totalItems += cart[productId];
            }
            document.querySelector('.cart-counter').textContent = totalItems;
        }

        function updateCartDropdown() {
            let cart = getCart();
            let cartDropdown = document.querySelector('.cart-dropdown');
            cartDropdown.innerHTML = '';

            if (Object.keys(cart).length === 0) {
                cartDropdown.innerHTML = '<p>No items in cart</p>';
            } else {
                for (let productId in cart) {
                    let quantity = cart[productId];
                    let productName = getProductName(productId);
                    cartDropdown.innerHTML += `<p>${productName} x${quantity} <button onclick="removeFromCart(${productId})">Remove</button></p>`;
                }
            }
        }

        function getProductName(productId) {
            const productNames = {
                1: '5 GoblinZ T-shirt',
                2: '5 GoblinZ Mug',
                3: '5 GoblinZ Beanie',
                4: '5 GoblinZ Keycap'
            };
            return productNames[productId] || 'Unknown Product';
        }

        window.onload = function () {
            updateCartCounter();
            updateCartDropdown();
        }
    </script>
    <style>
        .best-sellers-container {
            display: flex;
            justify-content: space-between;
            gap: 20px;
            margin: 20px;
        }

        .product-item {
            width: 23%;
            background-color: #f9f9f9;
            border-radius: 10px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .product-item a {
            text-decoration: none;
            color: #333333;
        }

        .product-item a:hover {
            color: black;
        }

        .product-item img {
            max-width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .product-item h2 {
            font-size: 18px;
            margin: 10px 0;
        }

        .product-item .price {
            font-size: 16px;
            margin: 10px 0;
        }

        .product-item button {
            background: #333;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            border-radius: 5px;
        }

        .product-item button:hover {
            background: #555;
        }

        @media (max-width: 1024px) {
            .best-sellers-container {
                flex-wrap: wrap;
            }
            .product-item {
                width: 42%;
            }
        }

        @media (max-width: 768px) {
            .product-item {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <div class="header happy-monkey-regular">🔥 Best Sellers! Limited Stock Available! 🔥</div>
    <img src="assets/images/5GZLOGO.png" alt="logo" style="border-radius: 250px; width: 50px; display: block; margin: 5px auto;">
    
    <nav class="navbar happy-monkey-regular">
        <ul class="nav-list">
            <li><a href="index1.html">Home</a></li>
            <li><a href="store.html">Store</a></li>
            <li class="dropdown">
                <a href="#teams" class="dropbtn">Products</a>
                <div class="dropdown-content">
                    <a href="T-shirts.php">T-shirts</a>
                    <a href="keycaps.php">Keycaps</a>
                    <a href="headwear.php">Headwear</a>
                    <a href="mugs.php">Mugs</a>
                </div>
            </li>
            <li><a href="bestsellers.php">Best Sellers</a></li>
        </ul>
    </nav>        

    <div class="cart-container">
        <a href="cartcheckout.html" class="cart-link">
            <div class="cart-icon">
                🛒 <span class="cart-counter">0</span>
            </div>
            <div class="cart-dropdown">
                <p>No items in cart</p>
            </div>
        </a>
    </div>

    <div class="best-sellers-container happy-monkey-regular">
        <div class="product-item">
            <a href="5goblinztshirt.php">
                <img src="assets/images/plainshirt1.png" alt="T-shirt">
                <h2>5 GoblinZ T-shirt</h2>
            </a>
            <p class="price">$<?php echo number_format($prices[1], 2); ?></p>
            <button onclick="addToCart(1)">Add to Cart</button>
        </div>

        <div class="product-item">
            <a href="5goblinzmug.php">
                <img src="assets/images/plainmug1.png" alt="Mug">
                <h2>5 GoblinZ Mug</h2>
            </a>
            <p class="price">$<?php echo number_format($prices[2], 2); ?></p>
            <button onclick="addToCart(2)">Add to Cart</button>
        </div>

        <div class="product-item">
            <a href="5goblinzbeanie.php">
                <img src="assets/images/plainbeanie1.png" alt="Beanie">
                <h2>5 GoblinZ Beanie</h2>
            </a>
            <p class="price">$<?php echo number_format($prices[4], 2); ?></p>
            <button onclick="addToCart(3)">Add to Cart</button>
        </div>

        <div class="product-item">
            <a href="5goblinzkeycap.php">
                <img src="assets/images/plainkeycap1.png" alt="Keycap">
                <h2>5 GoblinZ Keycap</h2>
            </a>
            <p class="price">$<?php echo number_format($prices[3], 2); ?></p>
            <button onclick="addToCart(4)">Add to Cart</button>
        </div>
    </div>

    <footer class="footer" style="margin-top: 197px;">
        <div class="footer-content">
            <p>&copy; 2025 5GZ Store. All rights reserved.</p>
            <p>Follow us on:
                <a href="#" target="_blank">Instagram</a> | 
                <a href="#" target="_blank">Twitter/X</a> | 
                <a href="#" target="_blank">TikTok</a>
            </p>
        </div>
    </footer>
</body>
</html>
